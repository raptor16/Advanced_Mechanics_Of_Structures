Dependencies you need: random, numpy, matplotlib
For bonus pip install scipy

Run Assignment3.py for questions 1 and 2. Sometimes, there is an unidentified bug so you have to keep rerunning it if it makes weird graphs. <-- I think it's fixed.
Look at the output on console for xopt and fopt. It'll output the graph at the end

Run Assignment3_part3.py; it is for question 3 with one pass penalty. This takes some time so I decided to print iteration number just to make sure it's not infinite looping -- you can take it out. It'll output xopt and fopt and the graph
Run Quadratic_penalty.py; it is for question 3 with quadratic penalty. Same as above for the outputs.
